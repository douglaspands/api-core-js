/**
 * @file Pesquisa possiveis rotas
 */
'use strict';
const path = require('path');
const searchFile = require('./middlewares/search-files');
const searchControllers = require('./middlewares/search-controllers');


const list = searchFile(path.join(__dirname, 'folder_1'));
const routes = searchControllers(list);

console.log(routes);

