/**
 * @file Controller de teste
 * @author xpto
 * @since 2017-12-29
 */
'use strict';
/**
 * @controller rest
 * @verb get
 * @uri /v1/usuarios
 */