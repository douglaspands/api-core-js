/**
 * @file Controller de teste
 * @author xpto
 * @since 2017-12-29
 */
'use strict';
/**
 * @controller rest
 * @verb post
 * @uri /v1/usuarios
 */