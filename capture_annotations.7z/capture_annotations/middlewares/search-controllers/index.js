/**
 * @file Procura controller nos arquivos
 * @author @douglaspands
 * @since 2017-12-28
 */
'use strict';
const fs = require('fs');
/**
 * Identifica notações abaixo para identificação se é uma controller e anota a rota.
 * @controller - tipo da api
 * @verb - verbo http
 * @uri - rota
 * @param {array} listFiles lista de arquivos .js para analisar
 * @return {array} Retorna uma lista de objetos contendo:
 * controller: tipo de api
 * verb: verbo http
 * uri: rota
 * file: endereço do arquivo
 */
function searchController(listFiles) {
    /**
     * Verifica se foi identificado todas as notações necessariaspara cadastro da rota.
     * @param {object} r Representa os parametros minimos pra cadastrar a rota.
     * @return {boolean} Retorna 'true' se a rota tiver o minimo necessario
     */
    function verifyRoute(r) {
        function includes(list, value) {
            const _list = (Array.isArray(list)) ? list : [];
            const _value = value;
            return _list.reduce((res, i) => {
                if (i === _value) res = true;
                return res;
            }, false);
        }
        return r.controller && r.controller.length > 0 &&
            r.verb && r.verb.length > 0 && includes(['get', 'put', 'post', 'patch', 'delete'], r.verb) &&
            r.uri && r.uri.length > 0;
    }
    return listFiles.reduce((routes, file) => {
        if ((/^(.+).js$/).test(file)) {
            const f = fs.readFileSync(file, 'utf8');
            const annotations = (f.match(/(@controller|@verb|@uri)\s(.+)?(?=[\n\s\t])/gi) || []);
            if (annotations.length > 0) {
                let route = annotations.reduce((_route, stringDoc) => {
                    let _parms = stringDoc.split(' ');
                    _parms[0] = _parms[0].replace('@', '');
                    _route[_parms[0]] = _parms[1].toLowerCase();
                    return _route;
                }, {});
                if (verifyRoute(route)) {
                    route['file'] = file;
                    routes.push(route);
                }
            }
        }
        return routes;
    }, []);
}

module.exports = searchController;